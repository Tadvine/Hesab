# دفتر حساب - Android APK project

This Android project packages the supplied Persian PWA in an Android WebView. It keeps the app's HTML/CSS/JS features and local browser storage inside the app. Printing is routed to Android's print service.

## Build APK
The included GitHub Actions workflow builds a debug APK on pushes to `main`/`master` or via Actions > Build Android APK > Run workflow. Download `daftar-hesab-apk` from the completed run's Artifacts section.
